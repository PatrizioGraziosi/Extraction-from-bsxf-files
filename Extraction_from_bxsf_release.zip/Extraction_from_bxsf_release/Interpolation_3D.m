% Written and developed by                                                %
% Patrizio Graziosi, patrizio.graziosi@warwick.ac.uk, during the          %  
% Marie Curie - Individual Fellowships  GENESIS - project ID 788465       %
% Generic transport simulator for new generation thermoelectric materials %
% ----------------------------------------------------------------------- %
% This file is distributed under the terms of the GNU                     %
% General Public License. See the file `LICENSE' in  the root directory   %
% of the present distribution.                                            %
% ----------------------------------------------------------------------- %
%                                                                         %
% Please cite the code source when publishing results obtained            %
% using the present code                                                  %
%                                                                         %
% ----------------------------------------------------------------------- %

for id_z=0:nk_new-1
        for id_y=0:nk_new-1
            for id_x=0:nk_new-1
                Kx_interp(id_x+1,id_y+1,id_z+1) = 1/nk_new*[id_x id_y id_z]*a' * 2*pi/(alat*1e-9) / norm(a);
                Ky_interp(id_x+1,id_y+1,id_z+1) = 1/nk_new*[id_x id_y id_z]*b' * 2*pi/(alat*1e-9) / norm(b);
                Kz_interp(id_x+1,id_y+1,id_z+1) = 1/nk_new*[id_x id_y id_z]*c' * 2*pi/(alat*1e-9) / norm(c);
%                 scatter3(K_position_x(id_x+1,id_y+1,id_z+1),K_position_y(id_x+1,id_y+1,id_z+1),K_position_z(id_x+1,id_y+1,id_z+1)); hold on
            end
        end
end

n_bands=size(Ek,4);
Ek_m=ones(nk_new,nk_new,nk_new,n_bands);
for i=1:n_bands
Ek_temp=Ek(:,:,:,i);
% Ek_m_temp=interp3(kx_matrix,ky_matrix,kz_matrix,Ek_temp,Kx_interp,Ky_interp,Kz_interp,'makima');
Ek_m_temp=griddata(kx_matrix,ky_matrix,kz_matrix,Ek_temp,Kx_interp,Ky_interp,Kz_interp);
Ek_m(:,:,:,i)=Ek_m_temp;
end
Ek=Ek_m;
kx_matrix=Kx_interp; ky_matrix=Ky_interp; kz_matrix=Kz_interp;
Ek_rough=Ek;
for i=1:size(Ek,4)
%     Ek(:,:,:,i)=smooth3(Ek_rough(:,:,:,i));
    Ek(:,:,:,i)=(Ek_rough(:,:,:,i));
end
clearvars -except Ek kx_array ky_array kz_array bands_interpolation nk_new bands_centering material_name kx_matrix ky_matrix kz_matrix alat a b c 